#include <stdio.h>
#include <stdlib.h>
#include "header.h"
//include header file here

int main()
{
	unsigned int num;
	printf("enter the unsigned integer number : " );
	scanf("%u",&num);
	printf("\n");

	unsigned char ch;
	printf("enter the unsigned character number between 0-255: " );
	scanf("%hhu",&ch);
	if (ch>255 && ch<0)
	{
		exit(EXIT_SUCCESS);
	}
	printf("\n");

	int low;
	printf("enter the value for low : " );
	scanf("%d",&low);
    printf("\n");
    
    int hi;
    printf("enter the value for high : " );
    scanf("%d",&hi);
    printf("\n");
    
    int num1; 
    printf("enter the first number : " );
    scanf("%d",&num1);
    printf("\n");
    
    int num2;
    printf("enter the second number : " );
    scanf("%d",&num2);
	printf("\n");

	printf("the bitwise addition is : " );
	addBitwise(num1,num2);
	printf("\n");
	
	int ans=isBitSetInRange(ch, low, hi);
	if (ans==0)
	{
		printf("the isBitSetInRange returned 0 ");
	    printf("\n");
	}
	else
	{
		printf("the isBitSetInRange returned 1 ");
	    printf("\n");
	}

	printf("the converstion of binary is : " );
    toBinary(num);
    printf("\n");
    
    printf("the converstion of octal is : " );
    toOctal(num);
    printf("\n");

	return 0;
}

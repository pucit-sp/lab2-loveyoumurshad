void addBitwise(int num1, int num2);

int isBitSetInRange(unsigned char ch, int low, int hi);

void toBinary(unsigned int num);

void toOctal(unsigned int num);

